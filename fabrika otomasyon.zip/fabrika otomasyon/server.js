const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const Database=require('better-sqlite3');
const db=new Database(path.join(__dirname,'fabrika.db'));
db.pragma('journal_mode=WAL');
db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE NOT NULL,name TEXT,role TEXT NOT NULL DEFAULT 'guard',salt TEXT,hash TEXT);
CREATE TABLE IF NOT EXISTS servis(id INTEGER PRIMARY KEY,plaka TEXT UNIQUE NOT NULL,sofor TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS kayit(id INTEGER PRIMARY KEY,tip TEXT NOT NULL,giris INTEGER NOT NULL,cikis INTEGER,plaka TEXT,ad TEXT,kimlik TEXT,firma TEXT,kime TEXT,neden TEXT,notlar TEXT,sofor TEXT,giris_km INTEGER,cikis_km INTEGER,servis_id INTEGER,kullanici TEXT);
CREATE INDEX IF NOT EXISTS k_ac ON kayit(tip,cikis);`);
db.exec(`CREATE TABLE IF NOT EXISTS basvuru(id INTEGER PRIMARY KEY,tarih INTEGER NOT NULL,ad TEXT NOT NULL,telefon TEXT,pozisyon TEXT,cv INTEGER DEFAULT 0,notlar TEXT,kullanici TEXT);`);
const cols=db.prepare('PRAGMA table_info(kayit)').all().map(c=>c.name);
for(const c of['bos_kg','dolu_kg'])if(!cols.includes(c))db.exec(`ALTER TABLE kayit ADD COLUMN ${c} INTEGER`);
const hash=(p,s)=>crypto.scryptSync(p,s,32).toString('hex');
function addUser(u,n,r,p){const s=crypto.randomBytes(16).toString('hex');db.prepare('INSERT INTO users(username,name,role,salt,hash) VALUES(?,?,?,?,?)').run(u,n,r,s,hash(p,s))}
if(!db.prepare('SELECT 1 FROM users').get()){addUser('admin','Yönetici','admin','admin123');console.log('İlk kullanıcı: admin / admin123  (giriş yapınca Yönetim bölümünden şifreyi değiştirin)')}
const sessions=new Map(),clients=new Set();
const send=(res,c,o,h={})=>{res.writeHead(c,{'Content-Type':'application/json',...h});res.end(JSON.stringify(o))};
const body=req=>new Promise(r=>{let b='';req.on('data',c=>b+=c);req.on('end',()=>{try{r(JSON.parse(b||'{}'))}catch{r({})}})});
const notify=()=>clients.forEach(c=>c.write('data: x\n\n'));
const cookie=req=>((req.headers.cookie||'').split(';').map(s=>s.trim().split('=')).find(a=>a[0]==='sid')||[])[1];
const S=v=>String(v??'').trim(),err=(res,m)=>send(res,400,{hata:m});
const num=v=>v===''||v==null||isNaN(+v)||+v<0?null:Math.round(+v);
http.createServer(async(req,res)=>{
 const p=new URL(req.url,'http://x').pathname,m=req.method;
 if(!p.startsWith('/api/')){if(p!=='/'){res.writeHead(404);return res.end()}res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});return res.end(fs.readFileSync(path.join(__dirname,'index.html')))}
 if(p==='/api/login'&&m==='POST'){const b=await body(req),u=db.prepare('SELECT * FROM users WHERE username=?').get(S(b.u));
  const ok=u&&crypto.timingSafeEqual(Buffer.from(hash(S(b.p),u.salt)),Buffer.from(u.hash));
  if(!ok)return send(res,401,{hata:'Kullanıcı adı veya şifre hatalı'});
  const t=crypto.randomBytes(24).toString('hex');sessions.set(t,{id:u.id,username:u.username,name:u.name,role:u.role});
  return send(res,200,{ok:1},{'Set-Cookie':`sid=${t}; HttpOnly; SameSite=Strict; Path=/`})}
 const me=sessions.get(cookie(req));
 if(!me)return send(res,401,{hata:'Giriş gerekli'});
 const adm=me.role==='admin',now=Date.now();let a;
 if(p==='/api/logout'){sessions.delete(cookie(req));return send(res,200,{ok:1})}
 if(p==='/api/events'){res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache',Connection:'keep-alive'});res.write('retry: 2000\n\n');clients.add(res);return void req.on('close',()=>clients.delete(res))}
 if(p==='/api/data')return send(res,200,{me,servis:db.prepare('SELECT * FROM servis ORDER BY plaka').all(),kayit:db.prepare('SELECT * FROM kayit ORDER BY giris DESC LIMIT 5000').all(),basvuru:db.prepare('SELECT * FROM basvuru ORDER BY tarih DESC LIMIT 3000').all(),users:adm?db.prepare('SELECT id,username,name,role FROM users ORDER BY username').all():[]});
 if(p==='/api/csv'){const c=['tip','giris','cikis','plaka','sofor','ad','kimlik','firma','kime','neden','notlar','giris_km','cikis_km','bos_kg','dolu_kg','kullanici'];
  const f=(k,v)=>'"'+String((k==='giris'||k==='cikis')&&v?new Date(v).toLocaleString('tr-TR'):v??'').replace(/"/g,'""')+'"';
  const rows=db.prepare('SELECT * FROM kayit ORDER BY giris DESC').all().map(r=>c.map(k=>f(k,r[k])).join(';'));
  res.writeHead(200,{'Content-Type':'text/csv; charset=utf-8','Content-Disposition':'attachment; filename=kayitlar.csv'});return res.end('\ufeff'+[c.join(';')].concat(rows).join('\n'))}
 const b=m==='GET'?{}:await body(req);
 try{
 if(p==='/api/kayit'&&m==='POST'){const t=b.tip,plaka=S(b.plaka).toUpperCase().replace(/\s+/g,' ');
  if(!['arac','ziyaretci','fason','yuk'].includes(t))return err(res,'Geçersiz tür');
  if(t==='arac'||t==='yuk'){if(!plaka||num(b.giris_km)===null||(t==='yuk'&&!S(b.firma)))return err(res,t==='yuk'?'Plaka, firma ve giriş KM zorunlu':'Plaka ve giriş KM zorunlu');
   if(db.prepare("SELECT 1 FROM kayit WHERE plaka=? AND cikis IS NULL AND tip IN('arac','servis','yuk')").get(plaka))return err(res,plaka+' zaten içeride')}
  if(t==='ziyaretci'&&!(S(b.ad)&&S(b.kimlik)&&S(b.kime)&&S(b.neden)))return err(res,'Zorunlu alanlar eksik');
  if(t==='fason'&&!S(b.ad))return err(res,'Ad soyad zorunlu');
  db.prepare('INSERT INTO kayit(tip,giris,plaka,ad,kimlik,firma,kime,neden,notlar,giris_km,bos_kg,dolu_kg,kullanici) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)').run(t,now,plaka||null,S(b.ad)||null,S(b.kimlik)||null,S(b.firma)||null,S(b.kime)||null,S(b.neden)||null,S(b.notlar)||null,t==='arac'||t==='yuk'?num(b.giris_km):null,t==='yuk'?num(b.bos_kg):null,t==='yuk'?num(b.dolu_kg):null,me.username);
  notify();return send(res,200,{ok:1})}
 if(a=p.match(/^\/api\/kayit\/(\d+)\/cikis$/)){const r=db.prepare('SELECT * FROM kayit WHERE id=?').get(a[1]);
  if(!r||r.cikis)return err(res,'Kayıt bulunamadı veya çıkış yapılmış');let km=null;
  if(r.giris_km!=null){km=num(b.km);if(km===null)return err(res,'Çıkış KM giriniz');if(km<r.giris_km)return err(res,'Çıkış KM giriş KM değerinden küçük olamaz')}
  db.prepare('UPDATE kayit SET cikis=?,cikis_km=?,bos_kg=COALESCE(bos_kg,?),dolu_kg=COALESCE(dolu_kg,?) WHERE id=?').run(now,km,num(b.bos),num(b.dolu),r.id);notify();return send(res,200,{ok:1})}
 if((a=p.match(/^\/api\/kayit\/(\d+)$/))&&m==='DELETE'){if(!adm)return send(res,403,{hata:'Yetkisiz'});db.prepare('DELETE FROM kayit WHERE id=?').run(a[1]);notify();return send(res,200,{ok:1})}
 if(a=p.match(/^\/api\/servis\/(\d+)\/hareket$/)){const s=db.prepare('SELECT * FROM servis WHERE id=?').get(a[1]);if(!s)return err(res,'Servis aracı yok');
  const km=num(b.km);if(km===null)return err(res,'KM giriniz');const o=db.prepare('SELECT * FROM kayit WHERE servis_id=? AND cikis IS NULL').get(s.id);
  if(o){if(km<o.giris_km)return err(res,'Çıkış KM giriş KM değerinden küçük olamaz');db.prepare('UPDATE kayit SET cikis=?,cikis_km=? WHERE id=?').run(now,km,o.id)}
  else db.prepare("INSERT INTO kayit(tip,giris,plaka,sofor,giris_km,servis_id,kullanici) VALUES('servis',?,?,?,?,?,?)").run(now,s.plaka,s.sofor,km,s.id,me.username);
  notify();return send(res,200,{ok:1})}
 if(p==='/api/basvuru'&&m==='POST'){if(!S(b.ad)||!S(b.telefon))return err(res,'Ad soyad ve telefon zorunlu');db.prepare('INSERT INTO basvuru(tarih,ad,telefon,pozisyon,cv,notlar,kullanici) VALUES(?,?,?,?,?,?,?)').run(now,S(b.ad),S(b.telefon),S(b.pozisyon)||null,b.cv?1:0,S(b.notlar)||null,me.username);notify();return send(res,200,{ok:1})}
 if(a=p.match(/^\/api\/basvuru\/(\d+)\/cv$/)){db.prepare('UPDATE basvuru SET cv=1-cv WHERE id=?').run(a[1]);notify();return send(res,200,{ok:1})}
 if((a=p.match(/^\/api\/basvuru\/(\d+)$/))&&m==='DELETE'){if(!adm)return send(res,403,{hata:'Yetkisiz'});db.prepare('DELETE FROM basvuru WHERE id=?').run(a[1]);notify();return send(res,200,{ok:1})}
 if(!adm)return send(res,403,{hata:'Yetkisiz'});
 if(p==='/api/servis'&&m==='POST'){const pl=S(b.plaka).toUpperCase().replace(/\s+/g,' ');if(!pl||!S(b.sofor))return err(res,'Plaka ve şoför zorunlu');db.prepare('INSERT INTO servis(plaka,sofor) VALUES(?,?)').run(pl,S(b.sofor));notify();return send(res,200,{ok:1})}
 if((a=p.match(/^\/api\/servis\/(\d+)$/))&&m==='DELETE'){if(db.prepare('SELECT 1 FROM kayit WHERE servis_id=? AND cikis IS NULL').get(a[1]))return err(res,'Araç şu an içeride, önce çıkış yapın');db.prepare('DELETE FROM servis WHERE id=?').run(a[1]);notify();return send(res,200,{ok:1})}
 if(p==='/api/users'&&m==='POST'){if(!S(b.username)||S(b.p).length<6)return err(res,'Kullanıcı adı ve en az 6 karakterli şifre gerekli');addUser(S(b.username),S(b.name),b.role==='admin'?'admin':'guard',S(b.p));notify();return send(res,200,{ok:1})}
 if((a=p.match(/^\/api\/users\/(\d+)\/sifre$/))){if(S(b.p).length<6)return err(res,'Şifre en az 6 karakter olmalı');const s=crypto.randomBytes(16).toString('hex');db.prepare('UPDATE users SET salt=?,hash=? WHERE id=?').run(s,hash(S(b.p),s),a[1]);return send(res,200,{ok:1})}
 if((a=p.match(/^\/api\/users\/(\d+)$/))&&m==='DELETE'){if(+a[1]===me.id)return err(res,'Kendi hesabınızı silemezsiniz');db.prepare('DELETE FROM users WHERE id=?').run(a[1]);notify();return send(res,200,{ok:1})}
 }catch(e){return err(res,e.code==='SQLITE_CONSTRAINT_UNIQUE'?'Bu kayıt zaten var':'Hata: '+e.message)}
 send(res,404,{hata:'Bulunamadı'});
}).listen(process.env.PORT||3000,()=>console.log('Çalışıyor: http://localhost:'+(process.env.PORT||3000)));
